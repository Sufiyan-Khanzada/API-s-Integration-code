
    <!-- footerstart -->
    <div id="footer1">
        <div class="iconfooter"><a href="index.php" class="changes1"><i class="fa-solid fa-house "></i></a>
        </div>
        <div class="iconfooter"><a href="message.php" class="changes1"><i class="fa-solid fa-comments "><span class="noti-alert">2</span></i></a></div>
        <div class="iconfooter"><a href="productupload.php" class="changes1"><i class="fa-solid fa-circle-plus "></i></a></div>
        <div class="iconfooter"><a href="notification.php" class="changes1"><i class="fa-solid fa-bell "><span class="noti-alert">1</span></i></a></div>
        <div class="iconfooter"><a href="login.php" class="changes1"><i class="fa-solid fa-user"></i></a></div>
    </div>

    <!-- footer end -->
    <!--===============================================================================================-->
